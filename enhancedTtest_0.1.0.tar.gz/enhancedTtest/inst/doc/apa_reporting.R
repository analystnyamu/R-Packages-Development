## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  echo = TRUE,
  warning = FALSE,
  message = FALSE,
  fig.width = 8,
  fig.height = 5,
  out.width = "100%"
)

# Load packages
library(enhancedTtest)
library(flextable)
library(ggplot2)

